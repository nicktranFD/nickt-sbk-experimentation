"""
This :mod:`abatar.viz_utils` module gathers visualisation routines 
"""

import matplotlib.pyplot as plt
import numpy as np


def plot_variants_dist(
    control: np.ndarray,
    target: np.ndarray,
    remove_zero: bool = False,
    log_scale: bool = False,
    bins: int = 50,
    density: bool = True,
    xlabel:str = None,
    ax:plt.axes = None,
) -> plt.axes:
    """Plot variants 1D distribution
          a. regular 1D hist
          b. regular 1D hist for non zero elements only
          c. log transformed 1D hist 

    Parameters
    ----------
    control : np.ndarray
        
    target : np.ndarray
        
    remove_zero : bool, optional
        default False
    log_scale : bool, optional
        by default False
    bins : int, optional
        by default 50
    density : bool, optional
        by default True
    xlabel : str, optional
        by default None
    ax : plt.axes, optional
        by default None

    Returns
    -------
    plt.axes
    """
    
    if ax == None:
        _, ax = plt.subplots(num=1)

    if remove_zero == True:
        _control = control[control > 0]
        _target = target[target > 0]

        print(f"Control non-null data: {100*len(_control)/len(control):0.2f}%")
        print(f"Target non-null data: {100*len(_target)/len(target):0.2f}%")

        control = _control
        target = _target

    if log_scale == True:
        target = np.log10(target)
        control = np.log10(control)

    if density == True:
        ax.set_ylabel("Density")
    else:
        ax.set_ylabel("Count")

    ax.hist(
        control,
        label="control",
        histtype="step",
        bins=bins,
        lw=2,
        density=density,
    )
    ax.hist(
        target,
        label="target",
        histtype="step",
        bins=bins,
        lw=2,
        density=density,
    )
    ax.legend()

    if xlabel:
        ax.set_xlabel(xlabel)
        
    return ax


# Plot uplift, median and percentile estimates
def plot_uplift(
    uplift,
    reference_line=None,
    xlabel="",
    levels=[2.5, 97.5],
    bounds=None,
    color="k",
    ax=None,
    title="Incremental Uplift [%]",
):
    """Plot uplift distribution w/o true uplift reference line.

    Parameters
    ----------
    uplift : _type_
        uplift distribution
    reference_line : _type_, optional
        observed uplift or a reference vertical line, by default None
    xlabel : str, optional
        by default ""
    levels : list, optional
        Confidence Interval, by default [16, 84]
    bounds: list, optional
        [lbound, central, mbound]
    color : str, optional
        by default "k"
    ax : _type_, optional
        by default None
    title : str, optional
        by default "Incremental Uplift [%]"

    Returns
    -------
    ax

    """

    if ax is None:
        _, ax = plt.subplots(figsize=(6,5))

    if levels:
        q1, q3 = np.percentile(uplift, levels)
        central = np.median(uplift)
    else:
        if bounds:
            q1, central, q3 = bounds
        
    ax.hist(
        uplift, label=xlabel, bins=50, histtype="step", color=color, lw=2
    )

    if reference_line is not None:
        ax.axvline(reference_line, lw=2, color="C2")

    # ypos to annotate vertical lines
    ytick = ax.get_yticks()[1]

    ax.axvline(q1, ls="dashed", color=color, alpha=0.4)

    ax.text(
        q1,
        ytick,
        f"CI",
        rotation=90,
        multialignment="center",
        fontsize=10,
    )

    ax.axvline(q3, ls="dashed", color=color, alpha=0.4)
    ax.text(
        q3,
        ytick,
        f"CI",
        rotation=90,
        multialignment="center",
        fontsize=10,
    )

    ax.axvline(central, ls="dashed", color=color, alpha=0.8)
    ax.text(
        central,
        ytick,
        f"Estimate",
        rotation=90,
        multialignment="center",
        fontsize=10,
    )

    ax.text(
        0.8,
        0.6,
        f"Estimate = {central:0.2f} \nLower CI = {q1:0.2f} \nUpper CI = {q3:0.2f}",
        horizontalalignment="center",
        verticalalignment="center",
        transform=ax.transAxes,
        fontsize=10,
    )

    ax.set_xlabel(title)
    # ax.minorticks_on()

    ax.set_title(xlabel, {'fontsize':10})

    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)
    ax.spines.left.set_visible(False)
    ax.set_yticks([])

    plt.tight_layout()
    plt.show()
    return ax
