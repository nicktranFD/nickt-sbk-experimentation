"""
This :mod:`abatar.power_estimator` module gathers power estimator routines
"""

import numpy as np
from abatar import PermutationTest
from statsmodels.stats.power import TTestIndPower
from statsmodels.stats.proportion import power_proportions_2indep, samplesize_proportions_2indep_onetail

class SimulatePower(object):
    """Simulate Power using PermutationTest method
    Refer to PermutationTest in the package for further details about the method itself.

    Example
    -------

    Experiment set up
    
    >>> mean, std = 100, 5
    >>> metric = np.random.normal(mean, std, 10000)
    >>> target_frac = 0.5
    
    Only mean of the distribution is shifted, variance is assumed to be unchanged

    >>> relative_uplift = 0.1    # 10%

    Simulate power

    >>> res = SimulatePower(metric, sample_size=500, effect_size=relative_uplift,
        target_frac=target_frac, alpha=0.05, test_stat='mean', n_iters=1000,
        n_permutations=1000, conversion=False)

    # One can make use of res.get_estimate method to get an estimate for a power of 0.8
    # before running the main simulation
    >>> res.get_estimate()    # to get estimates sample size for power=0.8 solving t/z tests

    # Simulation
    >>> power = res.simulate()

    """

    def __init__(
        self,
        metric: np.ndarray,
        sample_size: int,
        effect_size: float = 0.1,
        alpha: float = 0.05,
        target_frac: float = 0.5,
        n_iters: int = 5000,
        n_permutations: int = 1000,
        batch: int = 25,
        alternative: str = "two-sided",
        test_stat: str = 'mean',
    ) -> None:
        """_summary_

        Parameters
        ----------
        metric : np.ndarray
            _description_
        sample_size : int
            combined sample size of both variants
        effect_size : float, optional
            relative uplift, 0.1 ~= 10%, by default 0.1
        alpha : float, optional
            Type I error, by default 0.05
        target_frac : float, optional
            target to control sample size ratio, by default 0.5
        n_iters : int, optional
            Number of iterations simulation is run to estimate Power, by default 5000
        n_permutations : int, optional
            Number of permutations randomly selected from the metric, by default 1000
        batch : int, optional
            None
        alternative : str, optional
            'greater', 'less' or 'two-sided', by default "two-sided"
        test_stat : 'mean' optional
            median can be a good alternative, by default mean
        """

        self.metric = metric
        self._sample_size = sample_size
        self.effect_size = effect_size
        self.alpha = alpha
        self.target_frac = target_frac
        self.n_iters = n_iters
        self.n_permutations = n_permutations
        self.batch = batch
        
        self.test_stat = test_stat

        # Check whether metric is a conversion metric
        if len(set(np.unique(self.metric)) - set([0,1]))==0:
            self.conversion = True
        else:
            self.conversion = False

        self.alternative = alternative
        if self.alternative=='greater':
            self.ttest_alternative = 'larger'
        elif self.alternative=='less':
            self.ttest_alternative = 'small'
        else:
            self.ttest_alternative = 'two-sided'

        self.target_synth = None
        self.control_synth = None
        self.uplifted_target = None


        # Z/T tests parameters
        self.ratio =  self.target_frac/(1-self.target_frac)      # target/control sample ratio
        self.ttest_power = np.nan
        self.ttest_sample = np.nan
        self.ztest_power = np.nan
        self.ztest_sample = np.nan
        self.sim_power = np.nan

        self.__split_into_target_control()
        self.__apply_relative_uplift()

    # Setting sample size
    @property
    def sample_size(self):
        return self._sample_size
       
    @sample_size.setter
    def sample_size(self, nsample):
        self._sample_size = nsample

    def __split_into_target_control(self) -> None:
        """split into target/control"""
        sample = np.random.choice(
            self.metric, 
            size=(self.n_iters, self._sample_size), 
            replace=True)

        target_nind = int(self._sample_size * self.target_frac)
        self.target_synth, self.control_synth = (
            sample[:, :target_nind],
            sample[:, target_nind:],
        )

    def __apply_relative_uplift(self) -> None:
        if self.conversion == True:
            mean_base_target = np.mean(self.target_synth, axis=1)
            mean_uplifted_target = mean_base_target * (1 + self.effect_size)

            nconverts = np.array(
                mean_uplifted_target * self._sample_size
            ).astype(int)
            self.uplifted_target = np.zeros((self.n_iters, self._sample_size))

            for i, val in enumerate(nconverts):
                temp = np.array([1.0] * val + [0.0] * (self._sample_size - val))
                np.random.shuffle(temp)
                self.uplifted_target[i] = temp

        elif self.conversion == False:
            self.uplifted_target = self.target_synth * (1 + self.effect_size)

    def get_parametric_est(self, power=0.8):
        """
        Return estimated sample size for a power of 0.8
        solving for t or z tests. z tests for conversion metric
        """
        # parametric power calculation
        # If metric is binomial then proportion test
        # otherwize TTest

        print(f'---- Tentative sample size (power = {power}) --')

        if self.conversion==True:
            self.__ztest_sample_est(power)
            left_col = ['z_test sample']
            right_col = [f'{self.ztest_sample:.0f}']
        else:
            self.__ttest_sample_est(power)
            left_col = ['t-test sample']
            right_col = [f'{self.ttest_sample:.0f}']

        for a, b in zip(left_col, right_col):
            res_print = "{:<30}{:<}".format(a, b)
            print("{:<30}{:<}".format(a, b))
        return res_print

    def simulate(self) -> tuple[float]:
        """Simulate power

        Returns
        -------
        tuple[float]
            power
        """
        self.__split_into_target_control()
        self.__apply_relative_uplift()

        # parametric power calculation 
        # Run z/t tests
        if self.conversion==True:
            self.__ztest_power()
        else:
            self.__ttest_power()

        # non-parametric power calculation
        reject_H0 = []
        n_block_sample = 250
        n_blocks = self.n_iters//n_block_sample
        for i in range(n_blocks): 
            pt = PermutationTest(
            self.control_synth[i*n_block_sample : (i+1)*n_block_sample],
            self.uplifted_target[i*n_block_sample : (i+1)*n_block_sample],
            n_permutations=self.n_permutations,
            test_stat=self.test_stat,
            alpha=self.alpha,
            vectorized=True,
            alternative=self.alternative,
            axis=1)
            _, _, _, ireject_H0 = pt.run_test(verbose=False)
            reject_H0.extend(ireject_H0)

        self.sim_power = np.mean(reject_H0)
        return self.sim_power
    
    def __ttest_power(self) -> float:
        # Calculates power for a given sample 
        # using t-test
        analysis = TTestIndPower()
        self.ttest_power= analysis.power(
            effect_size=self.effect_size * np.mean(self.metric) / np.std(self.metric),
            nobs1=int(self._sample_size * (1-self.target_frac)),
            ratio=self.ratio,
            alpha=self.alpha,
            alternative=self.ttest_alternative)
        
    def __ttest_sample_est(self, power) -> float:
        # Calculates sample size for a fixed power
        analysis = TTestIndPower()
        nobs1 = analysis.solve_power(
            effect_size=self.effect_size * np.mean(self.metric) / np.std(self.metric),
            nobs1=None,
            ratio=self.ratio,
            power=power,
            alpha=self.alpha,
            alternative=self.ttest_alternative)
        
        self.ttest_sample = nobs1 + nobs1 * self.ratio
    
    def __ztest_power(self) -> float:
        # Calculates power for a given sample size using z-test
        # Applicable for conversion metric
        zpower = power_proportions_2indep(
            diff=self.effect_size * np.mean(self.metric),
            prop2=np.mean(self.metric),
            nobs1=int(self._sample_size * (1-self.target_frac)),
            ratio=self.ratio,
            alpha=self.alpha,
            alternative=self.alternative)
        
        self.ztest_power = zpower.power

    def __ztest_sample_est(self, power) -> float:
        # Calculates sample size for a fixed power as an estimate
        nobs1 = samplesize_proportions_2indep_onetail(
            diff=self.effect_size * np.mean(self.metric),
            prop2=np.mean(self.metric),
            power=power,
            ratio=self.ratio,
            alpha=self.alpha,
            alternative=self.alternative)
        
        self.ztest_sample = nobs1 + nobs1 * self.ratio

    def __str__(self) -> str:

        output = '---- Power Estimation --------------\n'
        left_col = ['Sample size', 
                    'Effect size',
                    'Significance level (alpha)',
                    'Simulated Power']
        
        right_col = [
            self.sample_size, 
            self.effect_size, 
            self.alpha,
            f'{self.sim_power:.2f}']

        for a, b in zip(left_col, right_col):
            output += "{:<30}{:<}\n".format(a, b)
        
        output += '-'*36 + '\n'

        return output
    
if __name__=="__main__":

    # Gaussian Distribution
    mean=50
    std=5
    nsample=500
    relative_uplift=0.02

    # Generate Synthetic Data
    metric = np.random.normal(mean, std, 10000)
    target_frac = 0.5

    # Bootstrapped power
    res = SimulatePower(
        metric,
        sample_size=nsample,
        effect_size=relative_uplift,
        target_frac=target_frac,
        alpha=0.05,
        test_stat='mean',
        n_iters=1500,
        n_permutations=2000,
        )

    res.get_parametric_est()
    res.simulate()
    res.sample_size = 800
    res.simulate()
