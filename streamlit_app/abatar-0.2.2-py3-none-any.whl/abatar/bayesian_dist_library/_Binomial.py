import pymc as pm
import numpy as np

def binomial(control_name, control_val, target_name, target_val):
    """Fit binomial distribution to data
    Priors on p -> Uniform Distribution

    Parameters
    ----------
    control_name : str
    control_val : array
        control value
    target_name : str
    target_val : array
        target value

    Returns
    -------
    mean of target, mean of control
    """
    
    nA = np.shape(control_val)[0]
    nB = np.shape(target_val)[0]

    pA = pm.Uniform("p" + f"_{control_name}", lower = 0.0, upper = 1.0)
    pB = pm.Uniform("p" + f"_{target_name}", lower = 0.0, upper = 1.0)
    
    pm.Binomial(control_name, p=pA, n=nA, observed=control_val)
    pm.Binomial(target_name, p=pB, n=nB, observed=target_val)

    meanA = pm.Deterministic("mean" + f"_{control_name}", nA*pA)
    meanB = pm.Deterministic("mean" + f"_{target_name}", nB*pB)
    
    return meanB, meanA