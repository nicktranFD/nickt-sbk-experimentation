import pymc as pm

def pareto(control_name, control_val, target_name, target_val):
    """Pareto dist

    Uniform prior on alphaA
    m is fixed and assumed to be min(control or target value)

    Parameters
    ----------
    control_name : _type_
        _description_
    control_val : _type_
        _description_
    target_name : _type_
        _description_
    target_val : _type_
        _description_

    Returns
    -------
    _type_
        _description_
    """

    alphaA = pm.Uniform("alpha" + f"_{control_name}", min(control_val),15)
    pm.Poisson(control_name, mu=alphaA, observed=control_val)

    alphaB = pm.Uniform("alpha" + f"_{target_name}", min(control_val),15)
    pm.Poisson(target_name, mu=alphaB, observed=target_val)

    meanA = pm.Deterministic("mean" + f"_{control_name}", alphaA*min(control_val)/(alphaA-1))
    meanB = pm.Deterministic("mean" + f"_{target_name}", alphaB*min(target_val)/(alphaB-1))
    return meanB, meanA