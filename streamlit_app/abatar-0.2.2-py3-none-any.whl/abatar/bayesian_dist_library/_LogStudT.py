import pymc as pm
import numpy as np

def log_studt(control_name, control_val, target_name, target_val):
    """Fit student-t distribution to log transformed data
    Priors on mean -> Normal
    Priors on std -> HalfNormal
    Priors on nu -> LogNormal

    Parameters
    ----------
    control_name : str
    control_val : array
        log transformed control value
    target_name : str
    target_val : array
        log transformed target value

    Returns
    -------
    mean of target, mean of control
    """
    
    muA = pm.Normal("mean_log" + f"_{control_name}", 
                    mu=np.mean(control_val), sigma=2)
    stdA = pm.HalfNormal("std_log" + f"_{control_name}", sigma=2)
    nuA = pm.LogNormal("nu_log" + f"_{control_name}", 1, 1)
    pm.StudentT(control_name, mu=muA, sigma=stdA, nu=nuA, observed=control_val)

    muB = pm.Normal("mean_log" + f"_{target_name}", 
                    mu=np.mean(target_val), sigma=2)
    stdB = pm.HalfNormal("std_log" + f"_{target_name}", sigma=2)
    nuB = pm.LogNormal("nu_log" + f"_{target_name}", 1, 1)
    pm.StudentT(target_name, mu=muB, sigma=stdB, nu=nuB, observed=target_val)

    # Not quite accurate estimate of inv log transformed mean,
    # particulary for the t-distribution but the final estimate
    # is tested to be a good estimate of observed value
    meanA = pm.Deterministic(
        "mean" + f"_{control_name}", np.exp(muA + 0.5 * stdA**2)
    )
    meanB = pm.Deterministic(
        "mean" + f"_{target_name}", np.exp(muB + 0.5 * stdB**2)
    )
    return meanB, meanA