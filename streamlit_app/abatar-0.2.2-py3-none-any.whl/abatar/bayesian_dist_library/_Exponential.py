import pymc as pm

def exponential(control_name, control_val, target_name, target_val):
    """Exponential Distribution

    Rate parameter assumed to have U[0,15] prior

    Parameters
    ----------
    control_name : _type_
        _description_
    control_val : _type_
        _description_
    target_name : _type_
        _description_
    target_val : _type_
        _description_

    Returns
    -------
    _type_
        _description_
    """

    lamA = pm.Uniform("lambda" + f"_{control_name}",  0, 15)
    pm.Exponential(control_name, lam=lamA, observed=control_val)

    lamB = pm.Uniform("lambda" + f"_{target_name}", 0,15)
    pm.Exponential(target_name, lam=lamB, observed=target_val)

    meanA = pm.Deterministic("mean" + f"_{control_name}", 1/lamA)
    meanB = pm.Deterministic("mean" + f"_{target_name}", 1/lamB)
    return meanB, meanA