import pymc as pm
import numpy as np

def studt(control_name, control_val, target_name, target_val):
    """Fit student-t distribution
    Priors on mean -> Normal
    Priors on std -> HalfNormal
    Priors on nu -> LogNormal

    Parameters
    ----------
    control_name : str
    control_val : array
        control value
    target_name : str
    target_val : array
        target value

    Returns
    -------
    mean of target, mean of control
    """
    
    meanA = pm.Normal("mean" + f"_{control_name}", 
                    mu=np.mean(control_val), sigma=10)
    stdA = pm.HalfNormal("std" + f"_{control_name}", sigma=10)
    nuA = 10 #pm.LogNormal("nu" + f"_{control_name}", 3, 1)
    pm.StudentT(control_name, mu=meanA, sigma=stdA, nu=nuA, observed=control_val)

    meanB = pm.Normal("mean" + f"_{target_name}", 
                    mu=np.mean(target_val), sigma=10)
    stdB = pm.HalfNormal("std" + f"_{target_name}", sigma=10)
    nuB = 10 #pm.LogNormal("nu" + f"_{target_name}", 3, 1)
    pm.StudentT(target_name, mu=meanB, sigma=stdB, nu=nuB, observed=target_val)

    return meanB, meanA