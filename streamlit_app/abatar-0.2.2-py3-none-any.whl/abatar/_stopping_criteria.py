"""
MSPRT
Reference: Peeking at A/B tests http://library.usc.edu.ph/ACM/KKD%202017/pdfs/p1517.pdf
"""

import numpy as np


def msprt(
    control_rv: np.ndarray,
    target_rv: np.ndarray,
    tau_sq: float,
    alpha: float = 0.1,
    null_diff: float = 0.0,
    min_n: int = 100,
) -> tuple[float, float, bool]:
    """Mixture Sequential Probability Ratio Test. Assumes equal sample size for control and target


    Parameters
    ----------
    control_rv : np.ndarray
        control random variable
    target_rv : np.ndarray
        target random variable
    tau_sq : float
        parameter on prior distribution of uplift, N(0, tau^2)
    alpha : float, optional
        type I error bound, by default 0.1
    null_diff : float, optional
        null hypothesis difference in means (default 0), by default 0.0
    min_n : int, optional
        , by default 100

    Returns
    -------

    test_statistic (float):
        integrated mixture likelihood ratio
    threshold (float):
        threshold to compare
    test_result (bool)

    Example
    -------

    >>>


    """

    mean_control = np.mean(control_rv)
    mean_target = np.mean(target_rv)

    # Calculate variance of control + target
    vn = np.std(control_rv) ** 2 + np.std(target_rv) ** 2
    # tau_sq = tau**2.0

    # n = (len(control_rv) + len(target_rv)) / 2.0
    n = min(len(control_rv), len(target_rv))  # Conservative criteria,
    # print(n)
    if n < min_n:
        test_statistic = 1.0
    else:
        test_statistic = np.sqrt(vn / (vn + n * tau_sq)) * np.exp(
            ((n**2) * tau_sq * (mean_target - mean_control - null_diff) ** 2)
            / (2 * vn * (vn + n * tau_sq))
        )

    test_result = test_statistic > 1.0 / alpha

    return test_statistic, 1.0 / alpha, test_result
