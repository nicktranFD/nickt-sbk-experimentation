import pymc as pm
import numpy as np

def gamma(control_name, control_val, target_name, target_val):
    """Gamma-Gamma distribution
    Exponential Priors on alpha and beta parameters

    Parameters
    ----------
    control_name : str
    control_val : array
    target_name : str
    target_val : array

    Returns
    -------
    mean target, mean control
    """

    if control_val.min()<=0:
        raise ValueError("Control value must be positive.")
    if target_val.min()<=0:
        raise ValueError("Target value must be positive.")
    

    alphaA = pm.Exponential("alpha" + f"_{control_name}", 10)
    betaA = pm.Exponential("beta" + f"_{control_name}", 100)
    pm.Gamma(control_name, alpha=alphaA, beta=betaA, observed=control_val)
    alphaB = pm.Exponential("alpha" + f"_{target_name}", 10)
    betaB = pm.Exponential("beta" + f"_{target_name}", 100)
    pm.Gamma(target_name, alpha=alphaB, beta=betaB, observed=target_val)
    meanA = pm.Deterministic("mean" + f"_{control_name}", alphaA/betaA)
    meanB = pm.Deterministic("mean" + f"_{target_name}", alphaB/betaB)

    return meanB, meanA