from abatar import PermutationTest, Bootstrap, MannWhitneyUTest
from abatar import Model, Inference
from abatar import plot_uplift
from typing import Dict
import logging

# if 'spark' not in locals():
#     from pyspark.sql import SparkSession
#     spark = SparkSession.builder.getOrCreate()

logging.basicConfig(level=logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)


def abtest(
        metric:Dict[str, float], 
        params:Dict, 
        metric_label:str=None) -> Dict:
    """A/B Test Main

    Example
    --------
    
    >>> target = np.array([8.53, 8.52, 8.01, 7.99, 7.93, 7.89, 7.85, 7.82, 7.8])
    >>> control = np.array([7.85, 7.73, 7.58, 7.4, 7.35, 7.3, 7.27, 7.27, 7.23])
    >>> metric = {'control': control, 'target': target}

    >>> params = {'permutation':
                    {'n_permutations': 5000, 'test_stat': np.mean},
                  'bootstrap':
                    {'test_stat': np.median, 'straps':25000},
                  'bayesian':
                    {'dist':'logstudt'}
                }
    >>> metric_label = None
    >>> abtest(metric, params, metric_label)


    Parameters
    ----------
    metric : Dict[str, float]
        metric vector/array for target/control
    params : Dict
        specify method(s) {permutation, bootstrap, bayesian, mannwhitneyu} 
        and their corresponding parameters
    metric_label : str, optional
        name of the metric e.g. stake, etv etc, by default None

    Output
    -------
    output: Dict[Dict] summary
    """

    control = metric['control']
    target = metric['target']

    output = {}

    if metric_label:
        control_name = 'control_' + metric_label
        target_name = 'target_' + metric_label
    else:
        control_name = 'control'
        target_name = 'target'

    if 'permutation' in params:
        logging.info("Run Permutation Test")
        
        test_params = params['permutation']

        pt = PermutationTest(
            control, 
            target, 
            **test_params)
        
        output['permutation'] = pt.run_test(verbose=True)

    if 'mannwhitneyu' in params:
        logging.info("Run MannWhitneyU Test")
        
        test_params = params['mannwhitneyu']

        pt = MannWhitneyUTest(
            control, 
            target, 
            **test_params
            )
        
        output['mannwhitneyu'] = pt.run_test(verbose=True)
        
    if 'bootstrap' in params:
        logging.info("Run Bootstrap Uplift")

        test_params = params['bootstrap']

        bt = Bootstrap(
            control, 
            target, 
            **test_params
            )
        output['bootstrap'] = bt.run_test(verbose=True)
        (uplift_dist, uplift_est), _ = output['bootstrap']

        plot_uplift(
            uplift_dist, 
            reference_line = 0,
            levels=None,
            bounds=uplift_est,
            color = 'C0',
            xlabel=metric_label)

    if 'bayesian' in params:

        test_params = params['bayesian']

        logging.info("Run Bayesian Inference")

        inf = Model(
            {control_name: control}, 
            {target_name: target}, 
            dist = test_params['dist']
            )
        
        model = inf.fit()
        res = Inference(model)

        res.plot_posteriors(manual=True)
        res.plot_uplift()

        res.summarise()

        output['bayesian'] = res.summary

    return output

# if __name__=="__main__":
#     import numpy as np
    
#     target = np.array([8.53, 8.52, 8.01, 7.99, 7.93, 7.89, 7.85, 7.82, 7.8])
#     control = np.array([7.85, 7.73, 7.58, 7.4, 7.35, 7.3, 7.27, 7.27, 7.23])

#     metric = {'control': control, 'target': target}

#     params = {'permutation':
#                 {'n_permutations': 15000, 'test_stat': np.mean, 'alternative':'two-sided'},
#               'bootstrap':
#                 {'test_stat': np.mean, 'straps':25000},
#               'mannwhitneyu':
#                 {'alternative':'two-sided'}
#         }
#     metric_label = None
#     abtest(metric, params, metric_label)