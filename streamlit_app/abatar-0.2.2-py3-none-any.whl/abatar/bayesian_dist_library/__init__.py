from . import (
    _Gamma,
    _LogStudT,
    _Binomial,
    _Multinomial,
    _BinomialStudtMixture,
    _Gaussian,
    _Binomial,
    _StudT,
    _Poisson,
    _Pareto,
    _Exponential,
    _SkewGaussian
)

gamma = _Gamma.gamma
logstudt = _LogStudT.log_studt
studt = _StudT.studt
poisson = _Poisson.poisson
binomial = _Binomial.binomial
multinomial = _Multinomial.multinomial
revenue = _BinomialStudtMixture.revenue
gaussian = _Gaussian.gaussian
binomial = _Binomial.binomial
pareto = _Pareto.pareto
exponential = _Exponential.exponential
skewgaussian = _SkewGaussian.skewgaussian