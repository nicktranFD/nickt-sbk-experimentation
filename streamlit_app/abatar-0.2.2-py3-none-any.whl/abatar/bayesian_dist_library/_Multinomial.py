def multinomial():
    return