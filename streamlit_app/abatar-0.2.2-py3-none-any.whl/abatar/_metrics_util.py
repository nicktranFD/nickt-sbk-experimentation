import pandas as pd
from IPython.display import display
import logging

if 'spark' not in locals():
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()

logging.basicConfig(level=logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)


class ExtractMetric():
    """Extract customer aggregated metric for a provided campaign name(s). 
    
    Methods available:
        get_campaign_metric
        describe

    Checks data for
        a. Duplicate customer ids in campaign data.
        b. Customer can't be in both Target and Control group.
    """
    def get_campaign_metric(
              self,
              campaign_name, 
              campaign_active, 
              print_query=True):
        """
        
        Parameters
        ----------
            campaign_name : str or list
                Name of a campaign available in 
                discovery_analyst.p_value_customer_list_repository
            campaign_active : str or list
                '1. Pre-Test', '2. In-Test', '3. Post-Test' etc
            print_query : bool
                True / False

        Returns
        -------
            df : pandas.DataFrame

        
        Extra information
        -----------------
        
        Uses following tables:
            discovery_analyst.dashboard_actives
            discovery_analyst.p_value_customer_list_repository
        

        >>> campaign_name = ["wc20230710_AFL_NRL_DW_Test", "wc20221114_MultiBR_Mass_2U0R_Test"]
        >>> campaign_active = ["2. In-Test", "1. Pre-Test", "3. Post-Test"]

        >>> metric = ExtractMetric()
        >>> df = metric.get_campaign_metric(campaign_name, campaign_active, print_query=False)
        >>> metric.describe()

        """

        if not isinstance(campaign_name, list):
            campaign_name = f"('{campaign_name}')"
        else:
            campaign_name = tuple(campaign_name)

        if not isinstance(campaign_active, list):
            campaign_active = f"('{campaign_active}')"
        else:
            campaign_active = tuple(campaign_active)

        query = f"""
                    SELECT 
                        dh.customer_id
                        , dh.campaign
                        , dh.campaign_active
                        , dh.t_or_c 
                        , cs.campaign_start_date
                        , cs.campaign_end_date
                        
                        , SUM(dh.active_week) as actives
                        , SUM(NVL(dh.playerdays,0.000))::float as playerdays 
                        , SUM(nvl(dh.BETS,0.000))::float as BETS   
                        , SUM(nvl(dh.TURNOVER,0.000))::float AS TURNOVER
                        , SUM(nvl(dh.CASH_TURNOVER,0.000))::float AS CASH_TURNOVER
                        , SUM(nvl(dh.CASH_PAYOUT,0.000))::float AS CASH_PAYOUT
                        , SUM(nvl(dh.BB_PAYOUT,0.000))::float AS BB_PAYOUT
                        , SUM(nvl(dh.GROSS_WIN,0.000))::float AS GROSS_WIN
                        , SUM(nvl(dh.COMBINED_GW,0.000))::float AS COMBINED_GW
                        , SUM(nvl(dh.NET_REVENUE,0.000))::float AS NET_REVENUE
                        , SUM(nvl(dh.EML_EXPECTED_NET_REVENUE,0.000))::float EML_EXPECTED_NET_REVENUE
                        , SUM(nvl(dh.EXPECTED_MARGIN_GEN,0.000))::float EXPECTED_MARGIN_GEN
                        , SUM(nvl(dh.FREEBETEGW,0.000))::float as FREEBETEGW
                        , SUM(nvl(dh.EXPECTED_ADJUSTED_GW,0.000))::float EXPECTED_ADJUSTED_GW
                        , SUM(nvl(dh.tot_ETV,0.000))::float tot_ETV
                        , SUM(dh.adj_gw)::float as adj_gw
                        , SUM(dh.GEN_COST)::float as GEN_COST
                        , SUM(dh.expected_gen_cost2)::float as expected_gen_cost2
                        , array_join(collect_set(dh.turnover_outlier), ',') as turnover_outlier
                        , array_join(collect_set(dh.enr_outlier), ',') as enr_outlier
                        , array_join(collect_set(dh.etv_group), ',') as etv_group
                        , array_join(collect_set(dh.lifecycle_stage), ',') as lifecycle_stage
                        , array_join(collect_set(dh.betting_preference), ',') as betting_preference
                        , array_join(collect_set(cs.value_tier), ',') as value_tier
                        , array_join(collect_set(cs.cat_preference), ',') as cat_preference

                    FROM discovery_analyst.dashboard_actives as dh
                    LEFT JOIN discovery_analyst.p_value_customer_list_repository as cs
                                    ON dh.customer_id=cs.customer_id 
                                    and dh.campaign=cs.campaign_name
                    WHERE
                        dh.campaign_active in {campaign_active}
                        and dh.campaign in {campaign_name}
                    GROUP BY 1, 2, 3, 4, 5, 6
                    """

        if print_query==True:
            print(query)

        logging.info("Querying Data")

        #logging.info('Querying Metric')
        self.df = spark.sql(query).toPandas()

        #Check sanity of T/C data
        logging.info('Data check initiated.')
        self.__check_data()
        logging.info('Data check completed.')

        return self.df
    
    def __check_data(self):
        # Check duplicate customers
        try:
            group = self.df.groupby(['campaign', 'campaign_active'], as_index=False) 
            assert group.size().sum()['size'] == group['customer_id'].nunique().sum()['customer_id']
        except AssertionError:
            print("Duplicate customer ids in campaign data.")

        # Check customers are non-overlapping between Target and Control
        try:
            # At max customer can be only in T or C
            assert 1 == (self.df
                        .groupby(['campaign', 'campaign_active', 'customer_id'])['t_or_c']
                        .nunique().max())
        except AssertionError:
            print("Customer can't be in both Target and Control group.")

    def describe(self):
        """Print top level campaign and variant information.
        """

        # Campaign end, start dates
        group = self.df.groupby(['campaign', 'campaign_active', 't_or_c']) 
        res = group.agg(customer_count=('customer_id', 'nunique'), 
                  campaign_end_date=('campaign_end_date', 'min'),
                  campaign_start_date=('campaign_start_date', 'min')
                  )
        display(res)

        # T/C proportion
        sample_size = self.df.groupby(['campaign', 'campaign_active', 't_or_c']).size() 
        sample_sum = self.df.groupby(['campaign', 'campaign_active']).size()
        t_c_proportion = pd.concat([sample_size, 
                                    (100*sample_size/sample_sum).round(2)], 
                                    axis=1, keys=['Count', '%Count'])
        display(t_c_proportion)