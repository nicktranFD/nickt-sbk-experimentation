import pymc as pm
import numpy as np

def gaussian(control_name, control_val, target_name, target_val):
    """Fit gaussian distribution to data
    Priors on mean -> Normal
    Priors on std -> HalfNormal

    Parameters
    ----------
    control_name : str
    control_val : array
        control value
    target_name : str
    target_val : array
        target value

    Returns
    -------
    mean of target, mean of control
    """
    
    meanA = pm.Normal("mean" + f"_{control_name}", 
                    mu=np.mean(control_val), sigma=2)
    stdA = pm.HalfNormal("std" + f"_{control_name}", sigma=2)
    pm.Normal(control_name, mu=meanA, sigma=stdA, observed=control_val)

    meanB = pm.Normal("mean" + f"_{target_name}", 
                    mu=np.mean(target_val), sigma=2)
    stdB = pm.HalfNormal("std" + f"_{target_name}", sigma=2)
    pm.Normal(target_name, mu=meanB, sigma=stdB, observed=target_val)

    return meanB, meanA