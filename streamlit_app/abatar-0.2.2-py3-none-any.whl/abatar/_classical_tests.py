"""
This :mod:`abatar.classical_tests` module gathers classical/frequents tests routines/algorithms
"""

import numpy as np
import scipy.stats as st
import logging
from typing import Tuple, Union, List
    
logging.basicConfig(level=logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# Null Hypothesis Significance Test
class PermutationTest:
    """2 sample, 1 or 2 sided hypothesis testing using non-parametric permutation method:
    Ho: no difference between mean(Target) and mean(Control)
    H1: there is a difference between mean(Target) and mean(Control)

    Notes:
    Suppose data contains two samples, e.g. control and target
    The data are pooled (concatenated), then randomly split and assigned to either
    the first or second sample, and the test statistic is calculated.
    This process is performed repeatedly (n_iters times)
    generating a distribution of the statistic under the null hypothesis.
    The observed statistic of the original data is compared to
    this distribution to determine the p-value.

    Ref: https://docs.scipy.org/doc//scipy/reference/generated/scipy.stats.permutation_test.html

    Methods
    -------

    run_test(verbose=True)

    Examples
    --------
    Pseudo-data

    >>> target = np.array([8.53, 8.52, 8.01, 7.99, 7.93, 7.89, 7.85, 7.82, 7.8])
    >>> control = np.array([7.85, 7.73, 7.58, 7.4, 7.35, 7.3, 7.27, 7.27, 7.23])

    Instantiate PermutationTest
    
    >>> pt = PermutationTest(control, target, n_permutations=5000, test_stat='mean', axis=-1)
    
    Run test
    
    >>> obs_stat, pvalue, null_dist, reject_H0 = pt.run_test(verbose=True)
    """

    def __init__(
        self,
        control: np.ndarray,
        target: np.ndarray,
        n_permutations: int = 5000,
        batch: int = None,
        test_stat: str = 'mean',
        alpha: float = 0.05,
        alternative: str = "two-sided",
        vectorized: bool = False,
        axis: int = 0,
        random_state: int = 42,
    ) -> None:
        """
        Parameters
        ----------
        control : np.ndarray
            Control sample data.
        target : np.ndarray
            Target sample data.
        n_permutations : int, optional
            Number of permutations, by default 5000.
        batch : int, optional
            Batch size for parallel computation, by default None.
        test_stat : str, optional
            Type of test statistic to use, by default 'mean'.
        alpha : float, optional
            Significance level, by default 0.05.
        alternative : str, optional
            Alternative hypothesis, by default "two-sided".
        vectorized : bool, optional
            Whether to use vectorized computation, by default False.
        axis : int, optional
            Axis for computation, by default 0.
        random_state : int, optional
            Random seed for reproducibility, by default 42.
        """
        
        self.control = control
        self.target = target
        self.n_permutations = n_permutations
        self.batch = batch
        self.alpha = alpha
        self.random_state = random_state
        self.vectorized = vectorized
        self.alternative = alternative
        self.axis = axis

        if test_stat == 'mean':
            self.func = np.mean
        elif test_stat == 'median':
            self.func = np.median
        else:
            raise AttributeError("test stat undefined.")
        self.test_stat = test_stat

    def run_test(self, verbose: bool = False) -> tuple:
        """
        Run permutation test.

        Parameters
        ----------
        verbose : bool, optional
            Whether to display verbose output, by default False.

        Returns
        -------
        tuple
            Observed statistic, p-value, null distribution, and reject_H0.
        """
        if self.vectorized:
            statistic_func = lambda x, y, axis: self.func(x, axis=axis) - self.func(y, axis=axis)
        else:
            statistic_func = lambda x, y: self.func(x) - self.func(y)

        res = st.permutation_test(
            (self.target, self.control),
            statistic_func,
            n_resamples=self.n_permutations,
            batch=self.batch,
            random_state=self.random_state,
            alternative=self.alternative,
            vectorized=self.vectorized,
            axis=self.axis,
        )

        obs_stat = res.statistic
        pvalue = res.pvalue
        null_dist = res.null_distribution

        if self.vectorized:
            reject_H0 = np.array(pvalue < self.alpha).astype(int)
        else:
            reject_H0 = int(pvalue < self.alpha)

        if verbose:
            message = self._generate_result_message(pvalue, obs_stat)
            logging.info(message)

        return obs_stat, pvalue, null_dist, reject_H0

    def _generate_result_message(self, pvalue: float, obs_stat: float) -> str:
        """
        Generate a result message based on the p-value and observed statistic.

        Parameters
        ----------
        pvalue : float
            The p-value of the test.
        obs_stat : float
            The observed test statistic.

        Returns
        -------
        str
            A message describing the test result.
        """
        alternative_desc = (
        "greater than" if self.alternative == "greater" else
        "less than" if self.alternative == "less" else
        "not equal to")

        test_conclusive = (
            "Conclusive" if pvalue < self.alpha else
            "Inconclusive")
        
        difference_significance = (
            "Stat. significant" if pvalue < self.alpha else
            "Not stat. significant")

        if self.alternative == "greater":
            H0 = "<"
            # HA = ">="
        elif self.alternative == "less":
            H0 = ">"
            # HA = "<="
        else:
            H0 = "="
            # HA = "!="

        if pvalue >= self.alpha:
            null_hypothesis_rejection = "Fail to reject"
        else:                
            null_hypothesis_rejection = "Reject"            

        null_hypothesis_line1 = (
            f"Null Hypothesis: mean(Target) {H0} mean(Control)")

        message = (
            f"\n{'-' * 81}\n"
            f"{'Permutation Test Attributes':<50}| {'Outputs':<30}\n"
            f"{'-'*50}|{'-'*30}\n"
            f"{'Null Hypothesis Test':<50}| {test_conclusive:<30}\n"
            f"{'Difference between the Target and Control':<50}| {difference_significance:<30}\n"
            f"{null_hypothesis_line1:<50}| {null_hypothesis_rejection:<30}\n"
            f"{'p-value':<50}| {pvalue:<30.6f}\n"
            f"{'Observed stat, i.e., mean(Target) - mean(Control)':<50}| {obs_stat:<30.3f}\n"
            f"\nIf we repeat the experiment many times, the likelihood of observing the difference\n"
            f"between Target and Control as extreme as {obs_stat:.3f} is {100*pvalue:.2f}%."
            f"\n{'-' * 82}\n"
        )
        return message


class MannWhitneyUTest:
    """
    Mann-Whitney U rank test on two independent samples.

    Ref: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html#scipy.stats.mannwhitneyu
    """

    def __init__(
        self,
        control: Union[list, np.ndarray],
        target: Union[list, np.ndarray],
        alpha: float = 0.05,
        use_continuity: bool = False,
        alternative: str = "two-sided"
    ) -> None:
        """
        Initialize MannWhitneyUTest object.

        Parameters
        ----------
        control : Union[list, np.ndarray]
            The control sample data.
        target : Union[list, np.ndarray]
            The target sample data.
        alpha : float, optional
            The significance level, by default 0.05.
        use_continuity : bool, optional
            Whether to use continuity correction, by default False.
        alternative : str, optional
            The alternative hypothesis, by default "two-sided".
        """
        self.control = control
        self.target = target
        self.use_continuity = use_continuity
        self.alternative = alternative
        self.alpha = alpha

    def run_test(self, verbose: bool = True) -> tuple:
        """
        Run the Mann-Whitney U test.

        Parameters
        ----------
        verbose : bool, optional
            Whether to print the result message, by default True.

        Returns
        -------
        tuple
            A tuple containing the test statistic, p-value, and rejection status.
        """
        res = st.mannwhitneyu(
            self.control,
            self.target,
            use_continuity=self.use_continuity,
            alternative=self.alternative,
            method='auto'
        )
        obs_stat = res.statistic
        pvalue = res.pvalue
        reject_H0 = int(pvalue < self.alpha)

        if verbose:
            message = self._generate_result_message(pvalue)
            logging.info(message)
        
        return obs_stat, pvalue, reject_H0

    def _generate_result_message(self, pvalue: float) -> str:
        """
        Generate a result message based on the p-value.

        Parameters
        ----------
        pvalue : float
            The p-value of the test.

        Returns
        -------
        str
            A message describing the test result.
        """
        if pvalue >= self.alpha:
            message = (
                f'Fail to reject the null hypothesis: '
                f'Distribution(Target) = Distribution(Control) '
                f'at the significance level of {self.alpha}'
            )
        else:
            message = (
                f'Reject the null hypothesis: '
                f'Distribution(Target) != Distribution(Control) '
                f'at the significance level of {self.alpha}'
            )
        
        return f"{message}\np-value = {pvalue:.6f}"

class Bootstrap:
    """
    Bootstrap (with replacement) observed value of the test statistic.
    Can accommodate different lengths for target and control vectors.
    """

    def __init__(
        self,
        control: Union[List[float], np.ndarray],
        target: Union[List[float], np.ndarray],
        test_stat: str = 'mean',
        straps: int = 5000
    ):
        """
        Initialize the BootstrapTest.

        Parameters
        ----------
        control : Union[List[float], np.ndarray]
            Control sample data.
        target : Union[List[float], np.ndarray]
            Target sample data.
        test_stat : str, optional
            Test statistic ('mean' or 'median'), by default 'mean'.
        straps : int, optional
            Number of bootstrap samples, by default 5000.
        """
        self.control = np.asarray(control)
        self.target = np.asarray(target)
        self.test_stat = test_stat
        self.straps = straps

    def run_test(
        self,
        verbose: bool = True
    ) -> Tuple[
        Tuple[np.ndarray, Tuple[float, float, float]],
        Tuple[np.ndarray, Tuple[float, float, float]]
    ]:
        """
        Run the bootstrap test.

        Parameters
        ----------
        verbose : bool, optional
            Whether to print detailed test results, by default True.

        Returns
        -------
        Tuple[
            Tuple[np.ndarray, Tuple[float, float, float]],
            Tuple[np.ndarray, Tuple[float, float, float]]
        ]
            Distribution of uplift and confidence interval for percentage uplift,
            and distribution of absolute uplift and confidence interval.
        """
        control_sample = np.random.choice(
            self.control,
            size=(self.straps, len(self.control)),
            replace=True
        )
        target_sample = np.random.choice(
            self.target,
            size=(self.straps, len(self.target)),
            replace=True
        )

        if self.test_stat == 'mean':
            test_stat_func = np.mean 
        else:
            test_stat_func = np.median

        control_cen = test_stat_func(control_sample, axis=-1)
        target_cen = test_stat_func(target_sample, axis=-1)

        uplift_percentage_dist = 100 * (target_cen - control_cen) / control_cen
        uplift_diff_dist = target_cen - control_cen

        # Percentage uplift
        percent_lbound = np.percentile(uplift_percentage_dist, 2.5)
        percent_ubound = np.percentile(uplift_percentage_dist, 97.5)
        percent_median = np.median(uplift_percentage_dist)
        uplift_percentage_est = (percent_lbound, percent_median, percent_ubound)

        # Absolute uplift
        diff_lbound = np.percentile(uplift_diff_dist, 2.5)
        diff_ubound = np.percentile(uplift_diff_dist, 97.5)
        diff_median = np.median(uplift_diff_dist)
        uplift_diff_est = (diff_lbound, diff_median, diff_ubound)

        if verbose:
            message = self._generate_result_message(
                uplift_percentage_est,
                uplift_diff_est
            )
            logging.info(message)

        return (
            (uplift_percentage_dist, uplift_percentage_est),
            (uplift_diff_dist, uplift_diff_est)
        )

    def _generate_result_message(
        self,
        uplift_percentage_est: Tuple[float, float, float],
        uplift_diff_est: Tuple[float, float, float]
    ) -> str:
        """
        Generate a result message based on the confidence intervals.

        Parameters
        ----------
        uplift_percentage_est : Tuple[float, float, float]
            Confidence interval for percentage uplift.
        uplift_diff_est : Tuple[float, float, float]
            Confidence interval for absolute uplift.

        Returns
        -------
        str
            A message describing the test result.
        """
        
        message = message = (
                f"\n{'-' * 62}\n"
                f"{'Bootstrap Attributes':<40}| {'Outputs':<20}\n"
                f"{'-'*40}|{'-'*21}\n"
                f"{'Incremental Uplift i.e. (T-C)/C':<40}| {uplift_percentage_est[1]:.2f}{'%':<20}\n"
                f"{'Confidence Interval (95%)':<40}| [{uplift_percentage_est[0]:<0.2f}, {uplift_percentage_est[2]:<0.2f}]%\n"
                f"{'Incremental Uplift [T-C]':<40}| {uplift_diff_est[1]:<20.2f}\n"
                f"{'Confidence Interval (95%)':<40}| [{uplift_diff_est[0]:<0.2f}, {uplift_diff_est[2]:<0.2f}]\n"
                f"{'-' * 62}\n"
            )
        return message