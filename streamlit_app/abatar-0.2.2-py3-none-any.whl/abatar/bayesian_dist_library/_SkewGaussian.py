import pymc as pm
import numpy as np

def skewgaussian(control_name, control_val, target_name, target_val):
    """Fit skew gaussian distribution to data
    Priors on mean -> Normal
    Priors on std -> HalfNormal
    Priors on alpha -> Uniform

    Parameters
    ----------
    control_name : str
    control_val : array
        control value
    target_name : str
    target_val : array
        target value

    Returns
    -------
    mean of target, mean of control
    """
    
    muA = pm.Normal("loc" + f"_{control_name}", 
                    mu=np.mean(control_val), sigma=np.std(control_val))
    stdA = pm.HalfNormal("std" + f"_{control_name}", sigma=np.std(control_val))
    alphaA = pm.Uniform("alpha" + f"_{control_name}", 0.1, 10)
    pm.SkewNormal(control_name, mu=muA, sigma=stdA, alpha=alphaA, 
                  observed=control_val)

    muB = pm.Normal("loc" + f"_{target_name}", 
                    mu=np.mean(target_val), sigma=np.std(target_val))
    stdB = pm.HalfNormal("std" + f"_{target_name}", sigma=np.std(target_val))
    alphaB = pm.Uniform("alpha" + f"_{target_name}", 0.1, 10)
    pm.SkewNormal(target_name, mu=muB, sigma=stdB, alpha=alphaB, 
                  observed=target_val)

    meanA = pm.Deterministic(
        "mean" + f"_{control_name}", muA + stdA*np.sqrt(2/np.pi)*alphaA/(1+alphaA**2)**0.5
    )
    meanB = pm.Deterministic(
        "mean" + f"_{target_name}", muB + stdB*np.sqrt(2/np.pi)*alphaB/(1+alphaB**2)**0.5
    )

    return meanB, meanA