def revenue():
    return