import pymc as pm

def poisson(control_name, control_val, target_name, target_val):
    """Poisson distribution

    lambda has uniform prior between [0,10]

    Parameters
    ----------
    control_name : _type_
        _description_
    control_val : _type_
        _description_
    target_name : _type_
        _description_
    target_val : _type_
        _description_

    Returns
    -------
    _type_
        _description_
    """


    lamA = pm.Uniform("lambda" + f"_{control_name}", 0, 10)
    pm.Poisson(control_name, mu=lamA, observed=control_val)


    lamB = pm.Uniform("lambda" + f"_{target_name}", 0, 10)
    pm.Poisson(target_name, mu=lamB, observed=target_val)

    meanA = pm.Deterministic("mean" + f"_{control_name}", lamA)
    meanB = pm.Deterministic("mean" + f"_{target_name}", lamB)
    return meanB, meanA