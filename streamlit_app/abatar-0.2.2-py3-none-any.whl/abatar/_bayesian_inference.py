import pandas as pd
import pymc as pm
import arviz as az
import matplotlib.pyplot as plt
import numpy as np
from .bayesian_dist_library import (gamma, logstudt, 
                                    gaussian, binomial,
                                    studt, poisson, pareto, 
                                    exponential, skewgaussian
                                    )


class Model:
    """Class to define model to fit
    """
    def __init__(self, control:dict, target:dict, dist:str)->None:
        """_summary_

        Parameters
        ----------
        control : dict
            {'name':array}
        target : dict
            {'name':array}
        dist : str
            options are 'gamma', 'logstudt', 'revenue', 
                        'binomial', 'multinomial', 'gaussian',
                        'studt', 'poisson', 'exponential'
        """

        log_transform = False
        
        if dist == "logstudt":
            self.func = logstudt
            log_transform = True
        elif dist == "gamma":
            self.func = gamma
        elif dist == "gaussian":
            self.func = gaussian
        elif dist == "poisson":
            self.func = poisson
        elif dist == "studt":
            self.func = studt
        elif dist == "binomial":
            self.func = binomial
        elif dist == "pareto":
            self.func = pareto
        elif dist == "exponential":
            self.func = exponential
        elif dist == "skewgaussian":
            self.func = skewgaussian
        else:
            raise ValueError(f"{dist} undefined.")
        
        self.control_name, self.control_val = self.__check_var(control, 
                                                               log_transform=log_transform)
        self.target_name, self.target_val = self.__check_var(target, 
                                                             log_transform=log_transform)

    def __check_var(self, var, log_transform=False):
        var_name, var_val = list(var.items())[0]

        if type(var_val) == pd.core.series.Series:
            var_val = var_val.values

        if log_transform==True:
            var_val = np.log(var_val)
            
        return var_name, var_val

    def fit(self):
        """Fit method

        Returns
        -------
        model instance
        """
        with pm.Model() as model:
            meanB, meanA = self.func(
                self.control_name,
                self.control_val,
                self.target_name,
                self.target_val,
            )
            pm.Deterministic("uplift", 100 * (meanB / meanA - 1))
        return model


class Inference:
    """Class to run Bayesian Inference
    """
    def __init__(self, model, niters=4000, tune=2000):
        """_summary_

        Parameters
        ----------
        model : instance
            
        niters : int, optional
            number of iteration/walks, by default 2000
            chains size is by default 4
        tune : int, optional
            burn-in sample size used for tuning, by default 1000
        """
        self.model = model

        with self.model:

            self.idata = pm.sample(
                niters,
                chains=4,
                tune=tune,
                progressbar=False,
                return_inferencedata=True,
            )

            self.ppc = pm.sample_posterior_predictive(
                self.idata, extend_inferencedata=True, progressbar=False
            )

        # Stack chains-draws of posteriors
        self.uplift = self.idata.posterior.stack(draws=("chain", "draw"))[
            "uplift"
        ]
        self.stacked_posterior = self.idata.posterior_predictive.stack(
            draws=("chain", "draw")
        )

        # Observed variable names
        self.varA, self.varB = list(self.idata.observed_data.data_vars)

    def plot_posteriors(self, xscale=None, manual=True):
        """Plot observed data against posteriors for a visual post predictive check  

        Parameters
        ----------
        xscale : str, optional
            scale of x-axis, by default None, alternative log
        manual : bool, optional
            if True plot posteriors manually using matplotlib 
            else makes use of default pymc plotting routine

            manual useful when data need to be transformed in log-scale etc. 
        """
        if manual == True:
            ax = self.__manual_plot_posteriors(xscale)
        else:
            fig, ax = plt.subplots(figsize=(10, 5), ncols=2)
            ax = az.plot_ppc(self.idata, num_pp_samples=100, ax=ax)

            if xscale == "log":
                ax[0].set_xscale("log")
                ax[1].set_xscale("log")
        return ax

    def __manual_plot_posteriors(self, xscale):

        fig, ax = plt.subplots(ncols=2, figsize=(8, 4))

        for i, var in enumerate([self.varA, self.varB]):
            
            # thinned_posterior = self.stacked_posterior[var][::500].T
            thinned_posterior = self.stacked_posterior[var][:,::200]
            obsv = self.idata.observed_data[var]

            if xscale == "log":
                thinned_posterior = np.log(thinned_posterior)
                obsv = np.log(obsv)

            # ax[i].hist(
            #     thinned_posterior,
            #     color=["k"] * thinned_posterior.shape[1],
            #     lw=2,
            #     alpha=0.05,
            #     histtype="step",
            #     bins=50,
            #     density=True,
            #     label="model",
            # )

            [ax[i].hist(thinned_posterior[:,j], 
                        histtype='step', 
                        alpha=0.05, 
                        color='k', 
                        bins=50, density=True) 
                        for j in np.arange(thinned_posterior.shape[1])]


            ax[i].hist(
                obsv,
                bins=50,
                density=True,
                histtype="step",
                lw=2,
                label="observed",
            )
            ax[i].legend()
            ax[i].set_xlabel(var)
            fig.suptitle("Model Fit")
        plt.tight_layout()
        return ax

    def plot_trace(self):
        ax = az.plot_trace(self.idata)
        plt.tight_layout()
        return ax

    def plot_uplift(
        self,
    ):
        """_summary_
        """
        _, ax = plt.subplots(figsize=(6,5))
        az.plot_posterior(self.idata, var_names=['uplift'], 
                          ref_val=0, ref_val_color='C2',
                          ax=ax, textsize=10)
        ax.set_xlabel('Incremental Uplift [%]')
        ax.set_title('')
        return ax

    def summarise(self):
        """_summary_

        Returns
        -------
        _type_
            _description_
        """
        self.summary = az.summary(
            self.idata, kind="stats", stat_focus="median", extend=True
        )
        print("Summary stats:")
        print(self.summary)

        prob = np.ones_like(self.uplift)
        prob_B_gt_A = prob[self.uplift > 0].sum() / prob.sum()
        prob_B_gt_A = round(100*prob_B_gt_A, 1)
        
        print(f"-------------------------------------------------------------------")
        print(f"Probability {self.varB} > {self.varA} = {prob_B_gt_A}%")

        uplift_est = self.summary.loc["uplift"]
        return uplift_est
